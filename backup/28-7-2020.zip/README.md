- Chạy "npm install" để cài các package cần thiết

- Để bắt đầu môi trường dev, chạy "npm start" 

- Để dev từng trang html thì tùy chỉnh trong file _vendors.json



-------------------------------------------------------
-------------------------------------------------------



- Thêm các thư viện front-end bằng file "config.json"
